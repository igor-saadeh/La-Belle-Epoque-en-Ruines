using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class GameEvents
{
    // Quando o personagem atinge o centro da c�mera
    //static public UnityEvent onPlayerCentered = new UnityEvent();
}
